## Elegant Free WordPress Theme
A 100% free GPL WordPress theme with built-in support for staff, portfolio, custom homepage and a blog.

* Demo: http://wpexplorer-demos.com/elegant/
* Landing Page: http://www.wpexplorer.com/elegant-free-wordpress-theme/


### Disclaimer
WPExplorer.com shall not be held liable for any damages, including, but not limited to, the loss of data or profit, arising from the use of, or inability to use, this product.